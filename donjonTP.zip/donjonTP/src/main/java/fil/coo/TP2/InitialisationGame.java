package fil.coo.TP2;

import characters.Player;

public interface InitialisationGame {
	public Room startingRoom();
	public Player startingPlayer();
}
